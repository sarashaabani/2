﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2
{
    public partial class Form1 : Form
    {
        int num1, num2, result;
        string str;

        private void button11_Click(object sender, EventArgs e)
        {
            num1 = int.Parse(textBox1.Text);
            textBox1.Text = "";
            str = "+";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            num1 = int.Parse(textBox1.Text);
            textBox1.Text = "";
            str = "-";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            num1 = int.Parse(textBox1.Text);
            textBox1.Text = "";
            str = "*";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            num1 = int.Parse(textBox1.Text);
            textBox1.Text = "";
            str = "/";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            num2 = int.Parse(textBox1.Text);
            if (str == "+")
                result = num1 + num2;
            else if (str == "-")
                result = num1 - num2;
            else if (str == "*")
                result = num1 * num2;
            else if (str == "/")
                result = num1 / num2;
            textBox1.Text = result.ToString();

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button a = (Button)sender;
            textBox1.Text += a.Text;
        }
    }
}
